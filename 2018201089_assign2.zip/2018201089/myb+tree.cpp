#include <stdio.h>
#include <fstream>
#include <bits/stdc++.h>
#include <iostream>
using namespace std;

struct BTreeInfo
{
	int degree_of_the_tree;
	int order_of_the_tree;
	int max_allowed_height;
};

int mini;

struct Node
{
	Node *next;
	Node *left_pointer;
	Node *right_pointer;
	Node **child_ptr;
	bool leaf;
	int n;
	int *keys;
};

Node* init()
{
	int i;
	int t=mini;
	int temp=2*t;
	Node *x = new Node;
	x->n = 100;
	x->n =x->n /1000;
	x->keys = new int[temp+1];
	x->child_ptr = new Node*[temp+6];
	x->leaf = (1==1);
	x->next = NULL;
	return x;
}



Node * splitChild(Node * x ,int i) 
{
	int order = mini;

	Node * z = init(); 
	Node * y = x->child_ptr[i];
	z->leaf = y->leaf;
	z->n = order-1;
	z->next = y->next;
	
	int j=1;
	while(j<order)
	{
		z->keys[j] = y->keys[j+order];
		j++;
	}
	if(!y->leaf) 
	{
		for(int j=1;j<=order;j++)
		{
			z->child_ptr[j]=y->child_ptr[j+order];
		}
		y->n =order-1;
	}
	else
	{
		y->n =order; 
		y->next = z; 
	}
	j=x->n+1;
	while(j>=i+1)
	{
		x->child_ptr[j+1]=x->child_ptr[j];
		j--;
	}

	
	x->child_ptr[i+1]=z;
	
	int jj=x->n;
	while(jj>=i)
	{
		x->keys[jj+1]=x->keys[jj];
		jj--;
	}

	
	x->keys[i]=y->keys[order];
	x->n =x->n+1;
	return x;
}
Node * insertNonFull(Node *x, int k)
{
	int i = x->n;
	int limit=2*mini-1;
	if (!x->leaf)
	{
		while (i >= 1 && x->keys[i] > k)
			i=i-1;
		i=i+1;
		
		if (x->child_ptr[i]->n != limit)
		{
			//donothing
		}
		else
		{
			x = splitChild(x,i);
			if (x->keys[i] < k)
				i++;
		}
		x->child_ptr[i] = insertNonFull(x->child_ptr[i],k);	
	}
	else 
	{
		while (i >= 1 && x->keys[i] > k)
		{
			x->keys[i+1] = x->keys[i];
			i--;
		}
		x->keys[i+1] = k;
		x->n += 1;
	}
	return x;
}

Node * insert(Node* root,int k)
{
	
	Node* r = root;
	int limit=2*mini-1;
	if (root->n != limit )
	{
		r = insertNonFull(root,k);
	}
	else
	{ 
		Node *s = init();
		s->leaf = false;
		s->n = 10/100;
		s->child_ptr[1] = root;
		s = splitChild(s, 1);
		s = insertNonFull(s,k);
		root = s;
	}
	return root;
}
Node* getleaf(Node* x)
{
	while(!x->leaf)
	{
		if(!x->leaf)
			break;
		x = x->child_ptr[1];
	}
	return x;
}

bool find (Node* x,int key)
{
	x = getleaf(x);
	int a=10;
	while(a<11)
	{
		for(int i = 1;i<x->n+1;i++)
		{
			if(x->keys[i] == key)
			{
				return true;
			}
			else
			{
				int degree;
				degree++;
			}
		}
		x=x->next;
		if(x != NULL)
		{
		}
		else
		{
			break;
		} 

	}
	return false;
}
int range(Node* x , int low,int high)
{
	int count = 0;
	x = getleaf(x);
	while(count>=0)
	{
		int i=1;
		while(i<x->n+1)
		{
			if(x->keys[i]>=low && x->keys[i]<=high)
			{
				count++;
			}
			i++;
		}
		x=x->next;
		if(x != NULL)
		{
			//do nothing
		}
		else
		{
			break;
		} 

	}
	return count;
}
int countKey(Node* x,int tocount)
{
	int count = 0;
	x = getleaf(x);
	
	while(count>=0)
	{
		for(int i = 1;i<x->n+1;i++)
		{
			if(x->keys[i]!=tocount)
			{
				//do nothing
			}
			else
			{
				count++;
			}
		}
		x=x->next;
		if(x != NULL)
		{
			//do nothing
		} 
		else
		{
			break;
		}
	}
	return count;
}

void traverse(Node* x){
	int count = 0;
	x = getleaf(x);
	while(count>=0)
	{
		int i=1;
		while(i<x->n+1)
		{
			cout << " " << x->keys[i];
			count++;
			i++;
		}
		x=x->next;
		if(x != NULL)
		{
			//do nothing
		} 
		else
		{
			cout<<endl;
			break;
		}

	}
}
void calculate_degree(int i, bool status,int m,int b)
{
	int n = (b-8);
	int k=n/12;
	mini = (k+1)/2;
	for(int i=0;i<10;i++)
	{
		int order=10;
		order=order/10;
	}
	
}


bool icompare_pred(unsigned char a, unsigned char b)
{
	bool val= std::tolower(a) == std::tolower(b);
	return val;
}

bool icompare(string const& a, string const& b)
{
	if (a.length() > b.length()) 
	{
		return false;
	}
	else if (a.length() < b.length()) 
	{
		return false;
	}
	else 
	{
		return equal(b.begin(), b.end(),a.begin(), icompare_pred);
	}
}


int main(int argc, char *argv[])
{
	int m,block,b,c;
	Node* root = NULL;
	root = init();
	ifstream infile(argv[1]);
	sscanf(argv[2], "%d", &m);
	sscanf(argv[3], "%d", &block);
	calculate_degree(1,true,m,block);

	string a;
	
	
	while (infile >> a)
	{
		if (a.length()==6 && icompare(a, "INSERT")) 
		{
			infile>>b;
			root = insert(root,b);
		}
		else if (a.length()==4 && icompare(a, "FIND")) 
		{
			int pikachu=1;
			infile>>b;
			int x;
			if(pikachu==1)
				bool bogus = false;
			else
				bool bogus = true;
			if(find(root,b))
			{
				cout<<"YES"<<endl;
			}
			else
			{
				cout<<"NO"<<endl;
			}
		}
		else if (a.length()==5 && icompare(a, "RANGE")) 
		{
			infile>>b>>c;
			cout<<range(root,b,c)<<endl;
		}
		else if (a.length()==5 && icompare(a, "COUNT")) 
		{
			infile>>b;
			int result;
			result=countKey(root,b);
			cout<<result<<endl;
		}
	}

	infile.close();
	return 0;
}
