B+ tree:
	g++ b+tree.cpp
	./a.out input.txt <M> <B>

Linear Hashing:
	g++ linearhashing.cpp
	./a.out input.txt <M> <B>
	

