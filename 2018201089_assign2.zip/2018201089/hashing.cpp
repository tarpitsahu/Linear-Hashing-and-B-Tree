#include <iostream>
#include <bits/stdc++.h>
using namespace std;

long int r=0;    
vector<vector<long int> > buckets;
long int sindex=0,step=2;

long int hashFunc(long int n)
{
    return pow(2,ceil(log2(n)) );
}


long int drop_msb(long int val)
{
    long int i;
    for(i=31;i>=0;i--)
    {
        if(val&(1<<i))
            break;
    }
    return val^(1<<i);
}

long int isKeyPresent(vector<long int> buckets1,long int key)
{
    long int size=buckets1.size();
    long int flag=0;

    for(long int i=0;i<size;i++)
    {
        if(buckets1[i]==key)
        {
            flag=1;
            break;
        }
    }    
    return flag;
}

long int insert(long int key,long int n)
{
    long int flag=0;
    long int hash;
    long int hash1 = hashFunc(n);

    hash=key%hash1;
    if(hash<0)
    {
        //do nothing
    }
    else
        hash=hash+hash1;
    
    while(hash>=buckets.size())
        hash=drop_msb(hash);

    if(isKeyPresent(buckets[hash],key))
    { 
        
    }   
    else
    {
        buckets[hash].push_back(key);
        r=r+1;
        flag=1;
    } 
    return flag;
}

void rehash(long int n)
{
    buckets.resize(n);
    long int mod = hashFunc(n);
    // cout<<"hello\n";
    vector<long int>items;
    for(long int i=0;i<buckets[sindex].size();i++)
    {
        items.push_back(buckets[sindex][i]);
    }
    buckets[sindex].clear();
    for(long int i=0;i<items.size();i++)
    {
        long int index = items[i]%mod;
        if(index >= 0)
            {
            //donothing
            }
        else
            index+=mod;
        while(index>=buckets.size())
            index=drop_msb(index);
        buckets[index].push_back(items[i]);
    }
    sindex++;
    if(sindex!=step)
    {
        //do nothing
    }
    else
    {
        sindex=0;
        step*=2;

    }
}

int main(int argc, char** argv) 
{
    string filename = argv[1];
    long int m = atoi(argv[2]);
    long int b = atoi(argv[3]);
    b=b/4;

    long int n=2; 
    buckets.resize(n);
    float occupancy;
    
    string val_to_insert;
    ifstream val_file(filename.c_str());

    while (getline(val_file,val_to_insert))
    {
        long int key = atoi(val_to_insert.c_str());        
        if(insert(key,n))
            cout<<key<<"\n";

        occupancy = float(r)/(b*n);     
        if(occupancy>0.75)
        {
            n++;
            rehash(n);
        }
    }
    return 0;
}